
#Name: Stevens, Evan
#Course: ICS4U
#File: Stevens_Evan_U3A3.py
#Description: Compare the efficiency of sorting algorithms
#Input: none
#Output: Efficiency of the lists
#algorithm/pseudocode:

# Define sorting functions:
# Selection Sort: Find the smallest item and move it to the correct position.
#Insertion Sort: Place each item in its correct place by comparing to previous items.
# Quick Sort: Divide the list, pick a pivot, and sort the partitions.
# Merge Sort: Split the list into two halves, sort them, and merge.
# Bubble Sort: Compare adjacent items and swap them if needed.
#Bogosort: Randomly shuffle until the list is sorted.

# Create a function to check if the list is sorted.
# Return True if the list matches the sorted version.

# Use time to measure how long each sorting function takes to run

# Loop for sorting tests:
#For each list size (10, 100, 1000), create random lists of numbers.
#Test each sorting algorithm with the generated list.
#Measure and store the time taken by each sorting method.

#Calculate average times:
# For each list size (10, 100, 1000), average the times of each algorithm.

# Output results to a file:
#Write the average time for each sorting algorithm for all list sizes.
#Identify and record the most efficient sorting algorithm based on the average times.

# Print the results:
# Read the file and display the results on the screen.

#History: 2024/12/03






import random
import time

def selection_sort(list):
    for i in range(len(list)):
        min_index = i

        for j in range(i + 1, len(list)):
            # select the minimum element in every iteration
            if list[j] < list[min_index]:
                min_index = j
        # swapping the elements to sort the array
        (list[i], list[min_index]) = (list[min_index], list[i])
    return list


def insertion_sort(list):
    # Traverse from the second element to the end of the array
    for i in range(1, len(list)):
        key = list[i]  # Current element to be positioned
        j = i - 1

        # Move elements of arr[0...i-1], that are greater than key, to one position ahead
        # of their current position
        while j >= 0 and list[j] > key:
            list[j + 1] = list[j]
            j -= 1

        # Place the key at its correct position
        list[j + 1] = key
    return list


# Function to find the partition position
def partition(list, low, high):
    # choose the rightmost element as pivot
    pivot = list[high]
    # pointer for greater element
    i = low - 1
    # traverse through all elements
    # compare each element with pivot
    for j in range(low, high):
        if list[j] <= pivot:
            # If element smaller than pivot is found
            # swap it with the greater element pointed by i
            i = i + 1
            # Swapping element at i with element at j
            (list[i], list[j]) = (list[j], list[i])
    # Swap the pivot element with the greater element specified by i
    (list[i + 1], list[high]) = (list[high], list[i + 1])
    # Return the position from where partition is done
    return i + 1
# function to perform quicksort
def quickSort(list, low, high):
    if low < high:
        # Find pivot element such that
        # element smaller than pivot are on the left
        # element greater than pivot are on the right
        pi = partition(list, low, high)
        # Recursive call on the left of pivot
        quickSort(list, low, pi - 1)
        # Recursive call on the right of pivot
        quickSort(list, pi + 1, high)

def merge(list, left, mid, right):
    n1 = mid - left + 1
    n2 = right - mid

    # Create temp arrays
    L = [0] * n1
    R = [0] * n2

    # Copy data to temp arrays L[] and R[]
    for i in range(n1):
        L[i] = list[left + i]
    for j in range(n2):
        R[j] = list[mid + 1 + j]

    i = 0  # Initial index of first subarray
    j = 0  # Initial index of second subarray
    k = left  # Initial index of merged subarray

    # Merge the temp arrays back
    # into arr[left..right]
    while i < n1 and j < n2:
        if L[i] <= R[j]:
            list[k] = L[i]
            i += 1
        else:
            list[k] = R[j]
            j += 1
        k += 1

    # Copy the remaining elements of L[],
    # if there are any
    while i < n1:
        list[k] = L[i]
        i += 1
        k += 1

    # Copy the remaining elements of R[],
    # if there are any
    while j < n2:
        list[k] = R[j]
        j += 1
        k += 1

def merge_sort(list, left, right):
    if left < right:
        mid = (left + right) // 2

        merge_sort(list, left, mid)
        merge_sort(list, mid + 1, right)
        merge(list, left, mid, right)

def print_list(list):
    for i in list:
        print(i, end=" ")
    print()



def is_sorted(list):
    """Check if the list is sorted"""
    return arr == sorted(arr)

def bogosort(list):
    """Sorts an array using Bogosort"""
    while not is_sorted(list):
        random.shuffle(list)  # Shuffle the list randomly
    return arr


def bubble_sort(list):
    n = len(list)
    # Loop through the array
    for i in range(n):
        # Track if any swapping happens
        swapped = False
        # Inner loop for comparing adjacent elements
        for j in range(0, n - i - 1):
            if list[j] > list[j + 1]:  # Swap if elements are in the wrong order
                list[j], list[j + 1] = list[j + 1], list[j]
                swapped = True
        # If no swaps occurred, the list is already sorted
        if not swapped:
            break
    return list


print("Program takes awhile to run, please wait patiently. You made us use Bogosort :). Hopefully your computer doesn't explode.")
print()
averageBogo=0

#test bogo sort with 5 digit lists so my computer doesn't crash
arr = []
for num in range (10):
    for num in range (5):
        arr.append(random.randint(1,10))
    startTime=time.perf_counter()
    sorted_arr = bogosort(arr)
    endTime=time.perf_counter()
    elapsedTime=endTime-startTime
    averageBogo=averageBogo+elapsedTime
    arr=[]
averageBogo=(averageBogo*1000)/5




currentList=[]


#selection sort averages
selSortAvgTime10=0
selSortAvgTime100=0
selSortAvgTime1000=0
selSortAvgTime=0

#insertion sort averages
insSortAvgTime10=0
insSortAvgTime100=0
insSortAvgTime1000=0
insSortAvgTime=0

#quick sort averages
qSortAvgTime10=0
qSortAvgTime100=0
qSortAvgTime1000=0
qSortAvgTime=0

#merge sort averages
merSortAvgTime10=0
merSortAvgTime100=0
merSortAvgTime1000=0
merSortAvgTime=0

#bub sort averages
bubSortAvgTime10=0
bubSortAvgTime100=0
bubSortAvgTime1000=0
bubSortAvgTime=0

counter = 0  # Tracks total iterations
maxValue = 100  # Maximum value for random numbers
listSize = 10  # Initial size of the list

for i in range(300):
            # Update listSize and maxValue based on counter
    if counter >= 200:
        listSize = 1000
        maxValue = 6000
    elif counter >= 100:
        listSize = 100
        maxValue = 1000
    else:
        listSize = 10
        maxValue = 100

            # Generate list
    currentList = [random.randint(1, maxValue) for _ in range(listSize)]

            # Create copies
    copy1 = currentList[:]
    copy2 = currentList[:]
    copy3 = currentList[:]
    copy4 = currentList[:]

            # Test Selection Sort
    startTime = time.perf_counter()
    sortedList = selection_sort(currentList)
    endTime = time.perf_counter()
    elapsedTime = (endTime - startTime)
    if len(currentList) == 10:
        selSortAvgTime10 += elapsedTime
    elif len(currentList) == 100:
        selSortAvgTime100 += elapsedTime
    elif len(currentList) == 1000:
        selSortAvgTime1000 += elapsedTime

            # Test Insertion Sort
    startTime = time.perf_counter()
    sortedList = insertion_sort(copy1)
    endTime = time.perf_counter()
    elapsedTime = (endTime - startTime)
    if len(copy1) == 10:
        insSortAvgTime10 += elapsedTime
    elif len(copy1) == 100:
        insSortAvgTime100 += elapsedTime
    elif len(copy1) == 1000:
        insSortAvgTime1000 += elapsedTime


    counter += 1  # Increment the counter after completing one go around


        #test with quick sort
    startTime = time.perf_counter()
    quickSort(copy2,0,len(currentList)-1)
    endTime = time.perf_counter()
    elapsedTime = (endTime - startTime)

    if len(copy2) ==10:
        qSortAvgTime10 = qSortAvgTime10 + elapsedTime

    elif len(copy2) ==100:
        qSortAvgTime100 = qSortAvgTime100 + elapsedTime

    if len(copy2) ==1000:
        qSortAvgTime1000 = qSortAvgTime1000 + elapsedTime


        #test with merge sort
    startTime = time.perf_counter()
    merge_sort(copy3,0,len(currentList)-1)
    endTime = time.perf_counter()
    elapsedTime = (endTime - startTime)

    if len(copy3)==10:
        merSortAvgTime10 = merSortAvgTime10 + elapsedTime

    elif len(copy3)==100 and len(copy3)>11:
        merSortAvgTime100 = merSortAvgTime100 + elapsedTime

    elif len(copy3)==1000:
        merSortAvgTime1000 = merSortAvgTime1000 + elapsedTime


    #test bubble sort
    startTime=time.perf_counter()
    bubble_sort(copy4)
    endTime=time.perf_counter()
    elapsedTime=(endTime-startTime)

    if len(copy4)==10:
        bubSortAvgTime10 = bubSortAvgTime10 + elapsedTime

    elif len(copy4)==100:
        bubSortAvgTime100 = bubSortAvgTime100 + elapsedTime

    elif len(copy4)==1000:
        bubSortAvgTime1000 = bubSortAvgTime1000 + elapsedTime


#Set all times into milliseconds
selSortAvgTime10=((selSortAvgTime10/100)*1000)
insSortAvgTime10=((insSortAvgTime10/100)*1000)
qSortAvgTime10=((qSortAvgTime10/100)*1000)
merSortAvgTime10=((merSortAvgTime10/100)*1000)
bubSortAvgTime10=((bubSortAvgTime10/100)*1000)

selSortAvgTime100=((selSortAvgTime100/100)*1000)
insSortAvgTime100=((insSortAvgTime100/100)*1000)
qSortAvgTime100=((qSortAvgTime100/100)*1000)
merSortAvgTime100=((merSortAvgTime100/100)*1000)
bubSortAvgTime100=((bubSortAvgTime100/100)*1000)

selSortAvgTime1000=((selSortAvgTime1000/100)*1000)
insSortAvgTime1000=((insSortAvgTime1000/100)*1000)
qSortAvgTime1000=((qSortAvgTime1000/100)*1000)
merSortAvgTime1000=((merSortAvgTime1000/100)*1000)
bubSortAvgTime1000=((bubSortAvgTime1000/100)*1000)


#Output results to a file
outputFile=open("OutputSorting.txt", 'w')
outputFile.write(f"The average for a 5 digit list using the most inefficient method possible, bogosort, is {averageBogo} milliseconds.\n")
outputFile.write("ALL VALUES REPRESENTED IN MILLISECONDS")
outputFile.write("\n")
outputFile.write("\n")
outputFile.write("Final Averages for 10 digit lists:\n")
outputFile.write("SELECTION SORT:\n")
outputFile.write(f"{str(selSortAvgTime10)} milliseconds.\n")

outputFile.write("INSERTION SORT:\n")
outputFile.write(f"{str(insSortAvgTime10)} milliseconds.\n")

outputFile.write("QUICK SORT:\n")
outputFile.write(f"{str(qSortAvgTime10)} milliseconds.\n")

outputFile.write("MERGE SORT:\n")
outputFile.write(f"{str(merSortAvgTime10)} milliseconds.\n")

outputFile.write("BUBBLE SORT:\n")
outputFile.write(f"{str(bubSortAvgTime10)} milliseconds.\n")
outputFile.write("\n")
outputFile.write("\n")
outputFile.write("Final Averages for 100 digit lists:\n")
outputFile.write("SELECTION SORT:\n")
outputFile.write(f"{str(selSortAvgTime100)} milliseconds.\n")

outputFile.write("INSERTION SORT:\n")
outputFile.write(f"{str(insSortAvgTime100)} milliseconds.\n")

outputFile.write("QUICK SORT:\n")
outputFile.write(f"{str(qSortAvgTime100)} milliseconds.\n")

outputFile.write("MERGE SORT:\n")
outputFile.write(f"{str(merSortAvgTime100)} milliseconds.\n")

outputFile.write("BUBBLE SORT:\n")
outputFile.write(f"{str(bubSortAvgTime100)} milliseconds.\n")
outputFile.write("\n")
outputFile.write("\n")
outputFile.write("Final Averages for 1000 digit lists:\n")
outputFile.write("SELECTION SORT:\n")
outputFile.write(f"{str(selSortAvgTime1000)} milliseconds.\n")

outputFile.write("INSERTION SORT:\n")
outputFile.write(f"{str(insSortAvgTime1000)} milliseconds.\n")

outputFile.write("QUICK SORT:\n")
outputFile.write(f"{str(qSortAvgTime1000)} milliseconds.\n")

outputFile.write("MERGE SORT:\n")
outputFile.write(f"{str(merSortAvgTime1000)} milliseconds.\n")

outputFile.write("BUBBLE SORT:\n")
outputFile.write(f"{str(bubSortAvgTime1000)} milliseconds.\n")


#get acerage time between all 3 lists lengths
selSortAvgTime=(selSortAvgTime10+selSortAvgTime100+selSortAvgTime1000)/3
insSortAvgTime=(insSortAvgTime10+insSortAvgTime100+insSortAvgTime1000)/3
qSortAvgTime=(qSortAvgTime10+qSortAvgTime100+qSortAvgTime1000)/3
merSortAvgTime=(merSortAvgTime10+merSortAvgTime100+merSortAvgTime1000)/3
bubSortAvgTime=(bubSortAvgTime10+bubSortAvgTime100+bubSortAvgTime1000)/3


outputFile.write("\n")
outputFile.write("\n")
outputFile.write("Final Averages for all lists:\n")
outputFile.write("SELECTION SORT:\n")
outputFile.write(f"{str(selSortAvgTime)} milliseconds.\n")

outputFile.write("INSERTION SORT:\n")
outputFile.write(f"{str(insSortAvgTime)} milliseconds.\n")

outputFile.write("QUICK SORT:\n")
outputFile.write(f"{str(qSortAvgTime)} milliseconds.\n")

outputFile.write("MERGE SORT:\n")
outputFile.write(f"{str(merSortAvgTime)} milliseconds.\n")

outputFile.write("BUBBLE SORT:\n")
outputFile.write(f"{str(bubSortAvgTime)} milliseconds.\n")



#check most efficient list

outputFile.write("\n")
if selSortAvgTime< insSortAvgTime and selSortAvgTime<qSortAvgTime and selSortAvgTime<merSortAvgTime and selSortAvgTime<bubSortAvgTime:
    outputFile.write("The most efficient considering all 3 lists was selection sort.")

elif insSortAvgTime< selSortAvgTime and insSortAvgTime<qSortAvgTime and insSortAvgTime<merSortAvgTime and insSortAvgTime<bubSortAvgTime:
    outputFile.write("The most efficient considering all 3 lists was insertion sort.")

elif qSortAvgTime< insSortAvgTime and qSortAvgTime<selSortAvgTime and qSortAvgTime<merSortAvgTime and qSortAvgTime<bubSortAvgTime:
    outputFile.write("The most efficient considering all 3 lists was quick sort.")

elif merSortAvgTime< insSortAvgTime and merSortAvgTime<qSortAvgTime and merSortAvgTime<selSortAvgTime and merSortAvgTime<bubSortAvgTime:
    outputFile.write("The most efficient considering all 3 lists was merge sort.")

elif bubSortAvgTime< insSortAvgTime and bubSortAvgTime<qSortAvgTime and bubSortAvgTime<merSortAvgTime and bubSortAvgTime<selSortAvgTime:
    outputFile.write("The most efficient considering all 3 lists was bubble sort.")


outputFile.close()
outputFile=open("OutputSorting.txt", 'r')

#print the lines in file
for line in outputFile:
    print(line)
outputFile.close()




































